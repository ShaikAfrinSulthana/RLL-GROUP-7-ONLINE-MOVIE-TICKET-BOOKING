//database-mysql
//localhost-3306

create database onlinemovie;
use onlinemovie;
select * from purchase;
select * from product;
select * from cart;

create table purchase (
id bigint not null,
 dop date,
 productname varchar(255), 
 quantity integer not null,
 totalcost float not null, 
 transactionid varchar(255), 
 customer_email varchar(255), 
 primary key (id));

create table product (id bigint not null, 
actual_price float not null, 
avail varchar(255), 
category varchar(255), 
des varchar(255), 
discount float not null, 
durations varchar(255), 
imagepath varchar(255), 
name varchar(255), 
price float not null, primary key (id));

create table customer(
email varchar(255) not null,
 address varchar(255), 
 contact varchar(255), 
 name varchar(255), 
 password varchar(255), 
 primary key (email)
 );
 
 
 select * from customer;
 
 create table cart (id bigint not null, 
 price float not null, 
 quantity integer not null, 
 product_id bigint, primary key (id));
 
 create table admin(
 username varchar(255) not null,
 password varchar(255),
 primary key (username)
 );
 select * from admin;
 
 
 
 